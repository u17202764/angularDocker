import { Routes } from '@angular/router';
import {ListadoComponent} from "./components/listado/listado.component";


export const routes: Routes = [
  { path: '', component: ListadoComponent }, // ruta por defecto

];
